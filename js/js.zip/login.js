function redirectToIndex(){
    window.location.href="../HTML/index.php";
}
function redirectToLogIn(){
    window.location.href="../HTML/guest-login.php";
}

function redirectToSignUP(){
    window.location.href="../HTML/sign-up.php"
}
