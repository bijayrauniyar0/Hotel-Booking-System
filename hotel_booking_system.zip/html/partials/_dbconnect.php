<?php
$server ="localhost";
$username="root";
$password = "";
$database = "hotelbookin002";

$conn = mysqli_connect($server, $username, $password, $database);
?>