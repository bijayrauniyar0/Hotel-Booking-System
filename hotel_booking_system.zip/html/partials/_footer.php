<link rel="stylesheet" href="../css/footer.css">
<footer id="#contact">
        <div class="container">
            <div class="social">
                <a href=""><i class="fa-brands fa-facebook"></i></a>
                <a href=""><i class="fa-brands fa-instagram"></i></a>
                <a href=""><i class="fa-brands fa-twitter"></i></a>
                <a href=""><i class="fa-brands fa-whatsapp"></i></a>
                <a href=""><i class="fa-brands fa-youtube"></i></a>
                <a href=""><i class="fa-solid fa-envelope"></i></a>
            </div>
            <div class="browse">
                <a href="">Home</a>
                <a href="">Rooms & Suites</a>
                <a href="">Login</a>
                <a href="">Book Now</a>
                <a href="">Sign Up</a>
            </div>
            <div class="copy-right">
                <p>&copy; 2024 All rights reserved</p>
            </div>
        </div>
    </footer>